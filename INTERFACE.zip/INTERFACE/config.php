<?php
$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'db_login';

$conn = mysqli_connect($server,$username, $password, $dbname);

?>