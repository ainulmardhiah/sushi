<?php
include "config.php";
 
 $id = $_GET['id'];

  $papar=mysqli_query($conn,"SELECT * FROM admin WHERE id='$id'");
  while ($res=mysqli_fetch_array($papar)) {
    # code...
    $username=$res['username'];
    $password=$res['password'];
  }
  ?>

<!DOCTYPE html>
<html>
<head>
  <title>Update | Registration</title>
</head>
<body>
  <form action="pros_update.php" method="POST">

    <h3>Update data dengan id=<?=$id?></h3>
    <hr>

  <label>id: </label>
   <input type="text" name="id" value="<?php echo $id; ?>">

    <br>
    <br>
    <label>Username: </label>
   <input type="text" name="username" value="<?php echo $username; ?>">

    <br>
    <br>

    <label>Password: </label>
    <input type="text" name="password" value="<?php echo $password; ?>">

    <br>
    <br>
    <input type="submit" name="update" value="Update">

  </form>
</body>
</html>



