<?php
include 'config.php';
  if(isset($_POST['update'])){
    $id=$_POST['id'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $edit = "UPDATE admin SET id='$id',username='$username', password= '$password' WHERE id='$id' ";
    $result = mysqli_query($conn, $edit);

    if ($result){
      header('location:view.php');
     // control data sent to the client or browser by the Web server before some other output has been sent
    }
    else {
      echo "OPS- FAILED !";
    }

  }