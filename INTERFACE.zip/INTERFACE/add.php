
<!DOCTYPE html>
<html>
<head>
  <title>Add | Registration</title>
</head>
<body>
  <form action="add.php" method="POST">

    <h3>TAMBAH ID </h3>
    <hr>
   
    <label>Email: </label>
    <input type="text" name="email">

    <br>
    <br>

    <label>Username: </label>
    <input type="text" name="username">

    <br>
    <br>

    <label>Password: </label>
    <input type="text" name="password">

    <br>
    <br>
    <input type="submit" name="submit" value="Done">
    
  </form>
</body>
</html>

<?php
  include "config.php";

  if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $edit = "INSERT INTO admin VALUES ('','$email','$username','$password');";
    $result = mysqli_query($conn, $edit);

    if ($edit){
      header("location:view.php");
    } 
    else {
      echo "OPS- FAILED !";
    }

  }

?>
