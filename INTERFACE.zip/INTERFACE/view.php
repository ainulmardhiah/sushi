<?php
include "config.php";
$sqli = "SELECT * FROM admin";
$result = mysqli_query($conn, $sqli); //$config itu berdasarkn config.php yg telah kita hubungkan
?>

<!DOCTYPE html>
<html>
<head>
	<title>View | Registration </title>
	<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>
	<br>
	<br>
	
	<table border="1" width="50%">
		<thead>
			<th>ID</th>
			<th>Email</th>
			<th>Username</th>
			<th>Password</th>
			<th>Action</th>
		</thead>
		<?php
		while($rows= mysqli_fetch_array($result)){ ?>
			<!-- fetches a result row as an associative array -->
		<tr>
			<td><?php echo $rows['id']?></td>
			<td><?php echo $rows['email']?></td>
			<td><?php echo $rows['username']?></td>
			<td><?php echo $rows['password']?></td>
			<td>
				<a href="update.php?id=<?php echo $rows['id'];?>">Update</a>
				|
				<a href="delete.php?id=<?php echo $rows['id'];?>">Delete</a>
			</td>
		</tr>
	<?php }?>
	</table><br>
	<center><a href="add.php">Add</a></center>
</body>
</html>