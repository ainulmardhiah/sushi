<?php
require "config.php";

$id = $_GET['id']; //get sesuai guna dkt delete sbb untk dptkn smula data
$sqli = "DELETE FROM admin WHERE id='$id'";
$execute = mysqli_query($conn, $sqli);

if ($execute){
	header("Location: view.php"); //sintaks ini untk ke laman read.php semula
}
else {
	echo "FAILED TO DELETE !";
}
?>