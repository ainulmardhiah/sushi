<?php
  include "config.php";

  if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $edit = "INSERT INTO admin VALUES ('','$email','$username','$password');";
    $result = mysqli_query($conn, $edit);

    if ($edit){
      header("location:view.php");
    } 
    else {
      echo "OPS- FAILED !";
    }

  }

?>